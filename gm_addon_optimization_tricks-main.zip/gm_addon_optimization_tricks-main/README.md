# gm_addon_optimization_tricks
Tips and Tricks to make your addon slim and fast

# CLI Tool
To install the required python packages run
```bash
pip install -r .\requirements.txt
```

After that the CLI can be ran with:
```bash
python main.py
```
![image](https://github.com/user-attachments/assets/dd785285-0023-433f-be9b-8d816c030d84)


## All documentation is stored in the Wiki
Please visit the Wiki to read more: https://github.com/CFC-Servers/gm_addon_optimization_tricks/wiki
