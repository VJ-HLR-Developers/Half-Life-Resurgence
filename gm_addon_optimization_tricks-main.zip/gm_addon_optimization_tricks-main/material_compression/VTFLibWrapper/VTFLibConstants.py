class Constants:
    uiMaximumResources = 32
